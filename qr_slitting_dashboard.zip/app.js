const SUPABASE_URL = "https://sfnnwctbsggspnextbwu.supabase.co";
const SUPABASE_KEY = "sb_publishable_QWUkDFwzYfbdBE6i7vKjYA_pAEBAPmv";
const supabase = window.supabase.createClient(SUPABASE_URL, SUPABASE_KEY);

const $ = id => document.getElementById(id);
const views = {public:$("publicView"), login:$("loginView"), admin:$("adminView")};

function showView(name){
  Object.values(views).forEach(v=>v.classList.add("hidden"));
  views[name].classList.remove("hidden");
}
function esc(v){return String(v??"").replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[m]));}

async function loadPublicJobs(){
  const {data,error}=await supabase.from("jobs").select("*").eq("status","Running").order("id",{ascending:true});
  if(error){$("publicJobs").innerHTML=`<div class="card">Unable to load jobs: ${esc(error.message)}</div>`;return;}
  $("publicEmpty").classList.toggle("hidden",data.length!==0);
  $("publicJobs").innerHTML=data.map(j=>`
    <article class="job-card">
      <h3>${esc(j.job||"Job")}</h3><div class="wo">${esc(j.wo)}</div>
      <div class="details">
        <div class="detail"><small>Machine</small><strong>${esc(j.machine)}</strong></div>
        <div class="detail"><small>Coil</small><strong>${esc(j.coil)}</strong></div>
        <div class="detail"><small>Grade</small><strong>${esc(j.grade)}</strong></div>
        <div class="detail"><small>Mill</small><strong>${esc(j.mill)}</strong></div>
        <div class="detail"><small>Weight</small><strong>${esc(j.weight)} kg</strong></div>
        <div class="detail"><small>Status</small><strong>🟢 ${esc(j.status)}</strong></div>
      </div>
    </article>`).join("");
}

async function loadAdminJobs(){
  const {data,error}=await supabase.from("jobs").select("*").order("id",{ascending:false});
  if(error){$("adminMsg").textContent=error.message;return;}
  $("adminJobs").innerHTML=data.map(j=>`
    <tr>
      <td>${esc(j.machine)}</td><td>${esc(j.wo)}</td><td>${esc(j.job)}</td><td>${esc(j.coil)}</td>
      <td>${esc(j.grade)}</td><td>${esc(j.mill)}</td><td>${esc(j.weight)}</td><td>${esc(j.status)}</td>
      <td><div class="actions">
        <button class="btn secondary small" onclick='editJob(${JSON.stringify(j)})'>Edit</button>
        <button class="btn danger small" onclick='deleteJob(${j.id})'>Delete</button>
      </div></td>
    </tr>`).join("");
}

async function openAdmin(){
  const {data:{session}}=await supabase.auth.getSession();
  if(session){showView("admin");$("logoutBtn").classList.remove("hidden");loadAdminJobs();}
  else showView("login");
}

$("adminLoginOpen").onclick=openAdmin;
$("backPublic").onclick=()=>showView("public");
$("logoutBtn").onclick=async()=>{await supabase.auth.signOut();$("logoutBtn").classList.add("hidden");showView("public");loadPublicJobs();};

$("loginForm").onsubmit=async e=>{
  e.preventDefault();$("loginMsg").textContent="Logging in...";
  const {error}=await supabase.auth.signInWithPassword({email:$("email").value,password:$("password").value});
  if(error){$("loginMsg").textContent=error.message;return;}
  $("loginMsg").textContent="";$("logoutBtn").classList.remove("hidden");showView("admin");loadAdminJobs();
};

function openModal(job=null){
  $("jobForm").reset();$("jobId").value=job?.id||"";
  $("modalTitle").textContent=job?"Edit Job":"New Job";
  if(job){["machine","wo","job","coil","grade","mill","weight","status"].forEach(k=>$(k).value=job[k]??"");}
  $("jobModal").classList.remove("hidden");
}
window.editJob=openModal;
$("newJobBtn").onclick=()=>openModal();
$("closeModal").onclick=$("cancelModal").onclick=()=>$("jobModal").classList.add("hidden");

$("jobForm").onsubmit=async e=>{
  e.preventDefault();
  const payload={machine:$("machine").value,wo:$("wo").value,job:$("job").value,coil:$("coil").value,grade:$("grade").value,mill:$("mill").value,weight:$("weight").value,status:$("status").value};
  let result;
  if($("jobId").value) result=await supabase.from("jobs").update(payload).eq("id",$("jobId").value);
  else result=await supabase.from("jobs").insert(payload);
  if(result.error){$("adminMsg").textContent=result.error.message;return;}
  $("jobModal").classList.add("hidden");$("adminMsg").textContent="Saved successfully.";loadAdminJobs();loadPublicJobs();
};

window.deleteJob=async id=>{
  if(!confirm("Delete this job?"))return;
  const {error}=await supabase.from("jobs").delete().eq("id",id);
  if(error){$("adminMsg").textContent=error.message;return;}
  loadAdminJobs();loadPublicJobs();
};

supabase.auth.onAuthStateChange((_event,session)=>{
  if(session){$("logoutBtn").classList.remove("hidden");}
});

loadPublicJobs();
